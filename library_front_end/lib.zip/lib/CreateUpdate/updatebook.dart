import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class UpdateBookForm extends StatefulWidget {
  final String? bookId;
  final String? imageUrl;
  final String? title;
  final String? author;
  final int? quantity;
  final String? publicationDate;
  final String? description;

  UpdateBookForm({this.bookId, this.imageUrl, this.title, this.author, this.quantity, this.publicationDate, this.description});

  @override
  _UpdateBookFormState createState() => _UpdateBookFormState();
}

class _UpdateBookFormState extends State<UpdateBookForm> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _authorController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();
  final TextEditingController _publicationDateController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _imageUrlController = TextEditingController();
  String? _imageUrl;

  Future<void> _submitForm() async {
    if (_formKey.currentState?.validate() ?? false) {
      final title = _titleController.text;
      final author = _authorController.text;

      // Parsing the quantity string to integer.
      final quantity = (_quantityController.text.isNotEmpty) ? int.tryParse(_quantityController.text) ?? 0 : 0;
      final quantityString = quantity.toString();

      final publicationDate = _publicationDateController.text;
      final description = _descriptionController.text;

      final bookData = {
        'title': title,
        'author': author,
        'quantity': quantityString,
        'image': _imageUrlController.text.isNotEmpty ? _imageUrlController.text : null,
        'publicationDate': publicationDate,
        'description': description,
      };

      final uri = widget.bookId == null
          ? Uri.parse('http://172.30.208.1:3000/books')
          : Uri.parse('http://172.30.208.1:3000/books/${widget.bookId}');
      final method = widget.bookId == null ? 'POST' : 'PUT';

      try {
        http.Response response;

        if (method == 'POST') {
          response = await http.post(
            uri,
            body: json.encode(bookData),
            headers: {'Content-Type': 'application/json'},
          );
        } else {
          response = await http.put(
            uri,
            body: json.encode(bookData),
            headers: {'Content-Type': 'application/json'},
          );
        }

        if (response.statusCode == 200) {
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                  content: Text('Book ${widget.bookId == null ? 'added' : 'updated'} successfully'),
                behavior: SnackBarBehavior.floating,
                margin: EdgeInsets.fromLTRB(20, 0, 20, 20),
              ));
        } else {
          throw Exception('Failed to save book');
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  @override
  void initState() {
    super.initState();
    if (widget.bookId != null) {
      _imageUrl = widget.imageUrl;
      _titleController.text = widget.title ?? '';
      _authorController.text = widget.author ?? '';
      _quantityController.text = widget.quantity?.toString() ?? '';
      _publicationDateController.text = widget.publicationDate ?? '';
      _descriptionController.text = widget.description ?? '';
      _imageUrlController.text = widget.imageUrl ?? '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      appBar: AppBar(
        backgroundColor: Colors.grey[100],
        title: Text(widget.bookId == null ? 'Add Book' : 'Update - ${widget.title}',style: TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.black,
          fontSize: 21,
        ),),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (_imageUrl != null && _imageUrl!.isNotEmpty)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.network(
                        _imageUrl!,
                        width: 200,
                        height: 250,
                        fit: BoxFit.cover,
                      ),
                      ],
                    ),
                  SizedBox(
                    height: 20,
                  ),
                  Divider(
                    thickness: 3,
                    color: Colors.indigo[900],
                  ),
                  TextFormField(
                    controller: _titleController,
                    decoration: InputDecoration(labelText: 'Title'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a title';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    controller: _authorController,
                    decoration: InputDecoration(labelText: 'Author'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter an author';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    controller: _quantityController,
                    decoration: InputDecoration(labelText: 'Quantity'),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a quantity';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    controller: _publicationDateController,
                    decoration: InputDecoration(labelText: 'Publication Date'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a publication date';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    controller: _descriptionController,
                    decoration: InputDecoration(labelText: 'Description'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a description';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    controller: _imageUrlController,
                    decoration: InputDecoration(labelText: 'Image URL (Optional)'),
                    keyboardType: TextInputType.url,
                  ),

                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _submitForm,
                    child: Text(widget.bookId == null ? 'Add Book' : 'Update Book'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.indigo[900],
                      foregroundColor: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
