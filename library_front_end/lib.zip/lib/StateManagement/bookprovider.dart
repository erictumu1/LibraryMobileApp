import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class BookProvider with ChangeNotifier {
  List<dynamic> _articles = [];
  List<dynamic> _filteredArticles = [];
  String _selectedCriteria = 'title';
  bool _isLoading = false;

  List<dynamic> get articles => _articles;
  List<dynamic> get filteredArticles => _filteredArticles;
  String get selectedCriteria => _selectedCriteria;
  bool get isLoading => _isLoading;

  void setSelectedCriteria(String criteria) {
    _selectedCriteria = criteria;
    notifyListeners();
  }

  Future<void> fetchData() async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await http.get(Uri.parse('http://172.30.208.1:3000/books'));
      if (response.statusCode == 200) {
        _articles = jsonDecode(response.body);
        _filteredArticles = _articles;
      } else {
        throw Exception('Failed to load data');
      }
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> searchBooks(String keyword) async {
    if (keyword.isEmpty) {
      _filteredArticles = _articles;
      notifyListeners();
      return;
    }

    try {
      final response = await http.get(
        Uri.parse('http://172.30.208.1:3000/books/search').replace(
          queryParameters: {
            'criteria': _selectedCriteria,
            'keyword': keyword,
          },
        ),
      );

      if (response.statusCode == 200) {
        _filteredArticles = jsonDecode(response.body);
      } else if (response.statusCode == 404) {
        _filteredArticles = [];
      } else {
        throw Exception('Failed to search books');
      }
    } catch (error) {
      print('Search error: $error');
    }

    notifyListeners();
  }

  Future<void> refreshData() async {
    await fetchData();
  }
}
