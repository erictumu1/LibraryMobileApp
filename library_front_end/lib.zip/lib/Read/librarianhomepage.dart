import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../Delete/deletebook.dart';
import '../CreateUpdate/updatebook.dart';

class librarianHomepage extends StatefulWidget {
  const librarianHomepage({super.key});

  @override
  State<librarianHomepage> createState() => _librarianHomepageState();
}

class _librarianHomepageState extends State<librarianHomepage>
    with TickerProviderStateMixin {
  late AnimationController controller;
  List<dynamic> articles = [];
  List<dynamic> filteredArticles = [];
  final TextEditingController searchController = TextEditingController();
  String selectedCriteria = 'title'; // Default search criteria

  @override
  void initState() {
    super.initState();
    fetchData();

    controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: 5),
    )..repeat();
  }

  // User Sign out
  void signOut() async {
    await FirebaseAuth.instance.signOut();
  }

  Future<void> fetchData() async {
    final response =
    await http.get(Uri.parse('http://172.30.208.1:3000/books'));

    if (response.statusCode == 200) {
      setState(() {
        articles = jsonDecode(response.body);
        filteredArticles = articles;
      });
    } else {
      throw Exception('Failed to load data');
    }
  }

  Future<void> searchBooks() async {
    final keyword = searchController.text.trim();
    if (keyword.isEmpty) {
      setState(() {
        filteredArticles = articles; // Reset to full list
      });
      return;
    }

    try {
      final response = await http.get(
        Uri.parse('http://172.30.208.1:3000/books/search').replace(
          queryParameters: {
            'criteria': selectedCriteria,
            'keyword': keyword,
          },
        ),
      );

      if (response.statusCode == 200) {
        setState(() {
          filteredArticles = jsonDecode(response.body);
        });
      } else if (response.statusCode == 404) {
        setState(() {
          filteredArticles = []; // No books found
        });
      } else {
        throw Exception('Failed to search books');
      }
    } catch (error) {
      print('Search error: $error');
    }
  }

  Future<void> refreshData() async {
    await fetchData();
  }

  Future<void> deleteBook(String bookId) async {
    final isDeleted = await DeleteBook.deleteBook(bookId);
    if (isDeleted) {
      setState(() {
        articles.removeWhere((article) => article['_id'] == bookId);
        filteredArticles = articles;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey[300],
        appBar: AppBar(
          backgroundColor: Colors.grey[100],
          leading: Icon(
            Icons.library_books_rounded,
            color: Colors.indigo[900],
            size: 30,
          ),
          title: Text(
            'Books Available',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.black,
              fontSize: 21,
            ),
          ),
          actions: [
            IconButton(
              onPressed: signOut,
              icon: Icon(Icons.logout, color: Colors.red),
            ),
          ],
        ),
        body: Column(
          children: [
            // Search Bar
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: searchController,
                decoration: InputDecoration(
                  hintText: 'Search by title or author...',
                  prefixIcon: Icon(Icons.search, color: Colors.indigo[900]),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onChanged: (value) {
                  searchBooks();
                },
              ),
            ),
            Expanded(
              child: RefreshIndicator(
                onRefresh: refreshData,
                color: Colors.indigo[900],
                child: filteredArticles.isEmpty
                    ? Center(
                  child: articles.isEmpty
                      ? CircularProgressIndicator(
                    color: Colors.indigo[900],
                  )
                      : Text(
                    'No books found',
                    style: TextStyle(
                        color: Colors.black, fontSize: 16),
                  ),
                )
                    : ListView.builder(
                  itemCount: filteredArticles.length,
                  itemBuilder: (context, index) {
                    final article = filteredArticles[index];
                    return Card(
                      color: Colors.white,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          article['image'] != null ?
                            Image.network(
                              article['image'],
                              width: 100,
                              height: 150,
                              fit: BoxFit.cover,
                            )
                        : Image.asset('lib/images/book.png',width: 100, height: 120, fit: BoxFit.cover,),
                          SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              mainAxisAlignment:
                              MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  article['title'] ?? 'No title',
                                  style: TextStyle(
                                    color: Colors.indigo[900],
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'Author: ${article['author'] ?? 'Unknown'}',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                  ),
                                ),
                                Text(
                                  'Quantity: ${article['quantity']}',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Row(
                                  children: [
                                    ElevatedButton(
                                      onPressed: () => {
                                      Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                      builder: (context) => UpdateBookForm(
                                          bookId: article['_id'],
                                          imageUrl: article['image'],
                                          title: article['title'],
                                          author: article['author'],
                                          quantity: article['quantity'],
                                          publicationDate: article['publicationDate'],
                                          description: article['description'],
                                      ),
                                      ),),},
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.orange,
                                      ),
                                      child: Text(
                                          'Update',
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold
                                          ),
                                      ),
                                    ),
                                    SizedBox(width: 10),
                                    ElevatedButton(
                                      onPressed: () => deleteBook(
                                          article['_id']),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.red,
                                      ),
                                      child: Text(
                                          'Delete',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                          ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: (){
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => UpdateBookForm()),
            );
          },
          child: Icon(
            Icons.add,
            color: Colors.white,
          ),
          backgroundColor: Colors.green[900],
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
        ),
      ),
    );
  }
}
