import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:library_front_end/Login/login.dart';
import 'dart:convert';
import 'bookdetails.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomescreenState();
}

class _HomescreenState extends State<Homepage> with TickerProviderStateMixin {
  late AnimationController controller;
  List<dynamic> articles = [];
  List<dynamic> filteredArticles = [];
  final TextEditingController searchController = TextEditingController();
  String selectedCriteria = 'title'; // Default search criteria

  @override
  void initState() {
    super.initState();
    fetchData();

    controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: 5),
    )..repeat();
  }


  //User Sign out
  void signOut() async {
    await FirebaseAuth.instance.signOut();
  }

  Future<void> fetchData() async {
    final response =
    await http.get(Uri.parse('http://172.30.208.1:3000/books'));

    if (response.statusCode == 200) {
      setState(() {
        articles = jsonDecode(response.body);
        filteredArticles = articles;
      });
    } else {
      throw Exception('Failed to load data');
    }
  }

  Future<void> searchBooks() async {
    final keyword = searchController.text.trim();
    if (keyword.isEmpty) {
      setState(() {
        filteredArticles = articles; // Reset to full list
      });
      return;
    }

    try {
      final response = await http.get(
        Uri.parse('http://172.30.208.1:3000/books/search').replace(
          queryParameters: {
            'criteria': selectedCriteria,
            'keyword': keyword,
          },
        ),
      );

      if (response.statusCode == 200) {
        setState(() {
          filteredArticles = jsonDecode(response.body);
        });
      } else if (response.statusCode == 404) {
        setState(() {
          filteredArticles = []; // No books found
        });
      } else {
        throw Exception('Failed to search books');
      }
    } catch (error) {
      print('Search error: $error');
    }
  }

  Future<void> refreshdata() async {
    await fetchData();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey[300],
        appBar: AppBar(
          backgroundColor: Colors.grey[100],
          leading: Icon(
            Icons.library_books_rounded,
            color: Colors.indigo[900],
            size: 30,
          ),
          title: Text(
            'Books Available',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.black,
              fontSize: 21,
            ),
          ),
          actions: [
            IconButton(onPressed: signOut, icon: Icon(Icons.logout, color: Colors.red,))
          ],
        ),
        body: Column(
          children: [
            // Search Bar
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: searchController,
                decoration: InputDecoration(
                  hintText: 'Search by title or author...',
                  prefixIcon: Icon(Icons.search, color: Colors.indigo[900]),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onChanged: (value) {
                  searchBooks();
                },
              ),
            ),
            // Refresh Indicator with ListView
            Expanded(
              child: RefreshIndicator(
                onRefresh: refreshdata,
                color: Colors.indigo[900],
                child: filteredArticles.isEmpty
                    ? Center(
                  child: articles.isEmpty
                      ? CircularProgressIndicator(
                    color: Colors.indigo[900],
                  )
                      : Text(
                    'No books found',
                    style: TextStyle(
                        color: Colors.black, fontSize: 16),
                  ),
                )
                    : ListView.builder(
                  itemCount: filteredArticles.length,
                  itemBuilder: (context, index) {
                    final article = filteredArticles[index];
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => BookDetails(
                              bookId: article['_id'],
                            ),
                          ),
                        );
                      },
                      child: Card(
                        color: Colors.white,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (article['image'] != null)
                              Image.network(
                                article['image'],
                                width: 100,
                                height: 150,
                                fit: BoxFit.cover,
                              ),
                            SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    article['title'] ?? 'No title',
                                    style: TextStyle(
                                        color: Colors.indigo[900],
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    'Author: ${article['author'] ?? 'Unknown'}',
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 18),
                                  ),
                                  Text(
                                    'Quantity: ${article['quantity']}',
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
